package com.ecommerce.application.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ecommerce.application.modal.Cart;
import com.ecommerce.application.modal.Category;



public interface CategoryRepo extends JpaRepository<Cart, Integer>{

	Category save(Category reg);

	List<Cart> findAll();



}