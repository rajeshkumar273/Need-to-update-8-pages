package com.ecommerce.application.service;

public class UserService {
	
	public boolean isEnabled() {
		return true;
	}

}
